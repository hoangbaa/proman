<template>
  <div class="space-y-6">
    <!-- Page header -->
    <div>
      <h1 class="text-3xl font-bold text-gray-900 dark:text-gray-100">
        History
      </h1>
      <p class="mt-2 text-gray-600 dark:text-gray-400">
        View comprehensive activity logs and track changes across all your projects.
      </p>
    </div>

    <!-- Coming Soon -->
    <div class="card p-12 text-center">
      <div class="text-6xl mb-6">📜</div>
      <h2 class="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">
        Global History
      </h2>
      <p class="text-gray-600 dark:text-gray-400 mb-6">
        This feature is currently under development. Soon you'll be able to view detailed activity logs across all your projects.
      </p>
      <div class="space-y-2 text-sm text-gray-500 dark:text-gray-400">
        <p>• Global activity timeline</p>
        <p>• Filter by project, user, or action type</p>
        <p>• Export activity reports</p>
        <p>• Audit trail for compliance</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
// This is a placeholder page for the history feature
</script>