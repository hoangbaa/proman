<template>
  <div class="space-y-6">
    <!-- Page header -->
    <div>
      <h1 class="text-3xl font-bold text-gray-900 dark:text-gray-100">
        Planner
      </h1>
      <p class="mt-2 text-gray-600 dark:text-gray-400">
        Plan and schedule your projects, tasks, and meetings with our integrated calendar system.
      </p>
    </div>

    <!-- Coming Soon -->
    <div class="card p-12 text-center">
      <div class="text-6xl mb-6">📅</div>
      <h2 class="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">
        Project Planner
      </h2>
      <p class="text-gray-600 dark:text-gray-400 mb-6">
        This feature is currently under development. Soon you'll have access to a comprehensive planning and scheduling system.
      </p>
      <div class="space-y-2 text-sm text-gray-500 dark:text-gray-400">
        <p>• Interactive calendar view</p>
        <p>• Schedule tasks and deadlines</p>
        <p>• Plan team meetings and events</p>
        <p>• Timeline and Gantt chart views</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
// This is a placeholder page for the planner feature
</script>