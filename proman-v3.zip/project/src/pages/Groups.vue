<template>
  <div class="space-y-6">
    <!-- Page header -->
    <div>
      <h1 class="text-3xl font-bold text-gray-900 dark:text-gray-100">
        Groups
      </h1>
      <p class="mt-2 text-gray-600 dark:text-gray-400">
        Create and manage groups to organize your teams and projects.
      </p>
    </div>

    <!-- Coming Soon -->
    <div class="card p-12 text-center">
      <div class="text-6xl mb-6">🏢</div>
      <h2 class="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">
        Groups Management
      </h2>
      <p class="text-gray-600 dark:text-gray-400 mb-6">
        This feature is currently under development. Soon you'll be able to create and manage groups for better team organization.
      </p>
      <div class="space-y-2 text-sm text-gray-500 dark:text-gray-400">
        <p>• Create and manage groups</p>
        <p>• Assign team members to groups</p>
        <p>• Set group permissions and roles</p>
        <p>• Organize projects by groups</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
// This is a placeholder page for the groups feature
</script>